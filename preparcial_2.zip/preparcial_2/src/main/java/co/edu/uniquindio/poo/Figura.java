package co.edu.uniquindio.poo;

public abstract class Figura {
    
    public abstract double calcularArea ();

}
