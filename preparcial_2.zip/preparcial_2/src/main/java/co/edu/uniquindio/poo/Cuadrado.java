package co.edu.uniquindio.poo;

public class Cuadrado extends Rectangulo{
    
    public Cuadrado (double alto, double ancho){
        super(ancho, alto);   
    }
}
